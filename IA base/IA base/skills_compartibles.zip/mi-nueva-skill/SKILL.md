---
name: mi-nueva-skill
description: Plantilla de ejemplo para crear habilidades personalizadas en Antigravity. Reemplaza esta descripción con el propósito de tu skill.
---

# Guía para Personalizar tu Habilidad

Usa esta plantilla para definir cómo quieres que actúe tu asistente cuando esta habilidad se active.

## 🎯 Instrucciones de Comportamiento
Aquí puedes detallar paso a paso cómo debe comportarse el asistente al ejecutar tareas relacionadas con esta habilidad:
- Regla 1: Explica qué enfoque técnico o metodológico debe priorizarse.
- Regla 2: Indica qué herramientas o dependencias prefiere que se usen.

## 🛠️ Recursos Adicionales (Opcional)
Si tu habilidad requiere más archivos, puedes estructurar tu carpeta de la siguiente manera:
- `/scripts/`: Scripts de ayuda o scripts de automatización.
- `/examples/`: Ejemplos prácticos de código o casos resueltos.
- `/resources/`: Archivos auxiliares, configuraciones o activos.
- `/references/`: Documentación más extensa (si supera las 500 líneas en este archivo).
